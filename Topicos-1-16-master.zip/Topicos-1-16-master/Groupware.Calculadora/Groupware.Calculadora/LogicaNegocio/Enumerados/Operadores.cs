﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Groupware.Calculadora.LogicaNegocio.Enumerados
{
    public enum Operadores
    {

       desconocido, Suma, 


    }
}